package semantic;

import AST.*;
import messages.Messages;
import optimizations.Optimizations;
import symbol.Symbol;
import symbol.SymbolTable;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * The type Semantic analysis.
 */
public class SemanticAnalysis {

    /* Symbol tables */
    private HashMap<String, SymbolTable> symbolTables = new HashMap<String, SymbolTable>();
    private SymbolTable globalSymbolTable = new SymbolTable();

    private String className;
    private boolean error = false;
    private boolean hasSuper = false;
    private String superName;
    private boolean staticContext = false;
    private Optimizations optimizations;

    /**
     * Instantiates a new Semantic analysis.
     *
     * @param optimizations the optimizations
     */
    public SemanticAnalysis(Optimizations optimizations) {
        this.optimizations = optimizations;
    }

    /**
     * Gets class name.
     *
     * @return the class name
     */
    public String getClassName() {
        return className;
    }

    /**
     * Gets symbol tables.
     *
     * @return the symbol tables
     */
    public HashMap<String, SymbolTable> getSymbolTables() {
        return symbolTables;
    }

    /**
     * Gets global symbol table.
     *
     * @return the global symbol table
     */
    public SymbolTable getGlobalSymbolTable() {
        return globalSymbolTable;
    }

    /**
     * Run semantic analysis.
     *
     * @param root the root
     * @return the boolean
     */
    public boolean run(Node root) {
        ASTClassDeclaration classDeclaration = (ASTClassDeclaration) root.jjtGetChild(0);
        className = classDeclaration.getName();
        if (classDeclaration.hasSuper()) {
            hasSuper = true;
            superName = classDeclaration.getSuper();
        }
        globalSymbolTable.setFunctionName(className);

        this.buildSymbolTables(classDeclaration);
        this.analyseBodies(classDeclaration);
        return error;
    }

    private void buildSymbolTables(Node classDeclaration) {

        for (int i = 0; i < classDeclaration.jjtGetNumChildren(); i++) {

            if (classDeclaration.jjtGetChild(i) instanceof ASTVarDeclaration) {

                registerVar(classDeclaration.jjtGetChild(i), null);

            } else if (classDeclaration.jjtGetChild(i) instanceof ASTMainDeclaration
                    || classDeclaration.jjtGetChild(i) instanceof ASTMethodDeclaration) {

                registerMethod(classDeclaration.jjtGetChild(i));

            }
        }
    }

    private void registerVar(Node declaration, SymbolTable table) {
        String type = declaration.jjtGetChild(0).getName();
        String name = ((SimpleNode) declaration.jjtGetChild(1)).image;
        SymbolTable symTable = (table != null) ? table : globalSymbolTable;
        if (symTable.getVariables().containsKey(name) || symTable.getParameters().containsKey(name)) {
            printRedefinedVar(name, declaration);
        } else {
            symTable.addVariable(name, type);
            if (symTable == globalSymbolTable) {
                globalSymbolTable.setInitialized(name);
            }
        }
    }

    private void registerMethod(Node declaration) {
        SymbolTable table = null;
        String signature = MethodSignature.fromDeclaration((SimpleNode) declaration).toString();
        if (declaration instanceof ASTMainDeclaration) {
            if (symbolTables.containsKey(signature)) {
                printRedefinedMethod(declaration.getName(), declaration);
                return;
            } else {
                table = new SymbolTable();
                table.setFunctionName("main");
                table.addParameter("args", "String[]"); // TODO: parameter name should be stored in parser
                table.setReturnType("void");

            }
        } else if (declaration instanceof ASTMethodDeclaration) {
            signature = MethodSignature.fromDeclaration((SimpleNode) declaration).toString();
            if (symbolTables.containsKey(signature)) {
                printRedefinedMethod(declaration.getName(), declaration);
                return;
            } else {
                String returnType = declaration.jjtGetChild(0).getName();
                table = new SymbolTable();
                if (!fillMethodParams((SimpleNode) declaration, table)) {
                    return;
                }
                table.setFunctionName(declaration.getName());
                table.setReturnType(returnType);
            }
        } else
            return;
        symbolTables.put(signature, table);
    }

    private boolean fillMethodParams(SimpleNode declaration, SymbolTable table) {
        boolean success = true;
        final ASTParameters parameters = (ASTParameters) declaration.jjtGetChild(1);
        for (int i = 0; i < parameters.jjtGetNumChildren(); i++) {
            String type = parameters.jjtGetChild(i).jjtGetChild(0).getName();
            String identifier = ((SimpleNode) parameters.jjtGetChild(i).jjtGetChild(1)).image;
            if (table.getParameters().containsKey(identifier)) {
                printRedefinedParameter(identifier, declaration.getName(), declaration);
                success = false;
            } else {
                table.addParameter(identifier, type);
            }
        }
        return success;
    }

    private void analyseBodies(Node root) {
        for (int i = 0; i < root.jjtGetNumChildren(); i++) {
            if (root.jjtGetChild(i) instanceof ASTMainDeclaration) {
                this.staticContext = true;
                analyseMethodBody((SimpleNode) root.jjtGetChild(i));
                this.staticContext = false;
            } else if (root.jjtGetChild(i) instanceof ASTMethodDeclaration) {
                analyseMethodBody((SimpleNode) root.jjtGetChild(i));
            }
        }
    }

    private void analyseMethodBody(SimpleNode method) {
        SymbolTable table = symbolTables.get(MethodSignature.fromDeclaration(method).toString());
        for (int i = 0; i < method.jjtGetNumChildren(); i++) {
            Node node = method.jjtGetChild(i);
            if (node instanceof ASTVarDeclaration) {
                registerVar(method.jjtGetChild(i), table);
            } else if (node instanceof ASTReturn) {
                String expectedReturn = table.getReturnType();
                String actualReturn = analyseExpression(node.jjtGetChild(0), table, false);
                if (actualReturn != null) {
                    if (!expectedReturn.equals(actualReturn)) {
                        printWrongReturnType(method);
                    }
                }
            } else {
                analyseStatement(node, table);
            }
        }
    }

    private void analyseStatement(Node statement, SymbolTable table) {
        if (statement instanceof ASTIf || statement instanceof ASTWhile) {
            if (statement.jjtGetChild(0) instanceof ASTBinaryExpr) {
                String exprType = analyseBinaryExpression(statement.jjtGetChild(0), table, false);
                if (exprType != null ? !exprType.equals("boolean") : true) {
                    printError("Expected expression to be evaluated as a boolean", statement);
                }
            }
            if (statement.jjtGetChild(1) instanceof ASTIfBody || statement.jjtGetChild(1) instanceof ASTWhileBody) {
                Node body = statement.jjtGetChild(1);
                for (int i = 0; i < body.jjtGetNumChildren(); i++) {
                    analyseStatement(body.jjtGetChild(i), table);
                }
            }
        } else if (statement instanceof ASTElseBody) {
            for (int i = 0; i < statement.jjtGetNumChildren(); i++) {
                analyseStatement(statement.jjtGetChild(i), table);
            }
        } else if (statement instanceof ASTIdentifierStat) {
            analyseInitialisation(statement, table);
        } else if (statement instanceof ASTExprStmt) {
            analyseExpression(statement.jjtGetChild(0), table, false);
        }
    }

    private void analyseInitialisation(Node statement, SymbolTable table) {
        String identifier = null;
        if (statement.jjtGetChild(0) instanceof ASTAssign) {
            Node assign = statement.jjtGetChild(0);
            String type = null;
            if (assign.jjtGetChild(0) instanceof ASTIdentifier) {
                identifier = ((ASTIdentifier) assign.jjtGetChild(0)).image;
                type = getTypeOrFail(identifier, table, statement);
                SymbolTable symTable = getTable(identifier, table);
                if (symTable != null) {
                    symTable.setInitialized(identifier);
                } else {
                    table.setInitialized(identifier);
                }
                if (assign.jjtGetChild(1) instanceof ASTLeaf) {
                    ASTLeaf leaf = (ASTLeaf) assign.jjtGetChild(1);
                    if (optimizations.getOptionO() && leaf.getType() == JmmConstants.INTEGERLITERAL) {
                        table.setConstant(identifier, Integer.parseInt(leaf.image));
                    }

                } else if (optimizations.getOptionO()) {
                    table.setConstant(identifier, -1);
                }
            } else if (assign.jjtGetChild(0) instanceof ASTArrayAccess) {
                identifier = ((ASTIdentifier) assign.jjtGetChild(0).jjtGetChild(0)).image;
                SymbolTable symTable = getTable(identifier, table);
                if (symTable != null) {
                    if (!symTable.getInitialized(identifier)) {
                        printError("Array " + identifier + " not initialized", statement);
                    }
                }
                type = getTypeOrFail(identifier, table, statement);
                if (type != null) {
                    if (type.equals("int[]"))
                        type = "int";
                }
                String indexType = analyseExpression(assign.jjtGetChild(0).jjtGetChild(1), table, false);
                if (indexType != null ? !indexType.equals("int") : true) {
                    printError("The index of the array must be an int.", statement);
                }
            }
            String rhsType = analyseExpression(assign.jjtGetChild(1), table, false);
            HashSet<String> primitives = new HashSet<>(Arrays.asList("int", "int[]", "boolean"));
            if (rhsType != null && type != null) {
                if (!rhsType.equals(type)) {
                    if (primitives.contains(rhsType) || primitives.contains(type)) {
                        printError("Expression types do not match.", statement);
                        return;
                    }
                    if (rhsType.equals(this.className) && ((this.hasSuper && !type.equals(this.superName)) || !this.hasSuper)) {
                        printError(this.className + " does not extend " + type, statement);
                        return;
                    }
                }

            }
        }
    }

    private String analyseExpression(Node expression, SymbolTable table, boolean isDotExpr) {
        if (expression instanceof ASTBinaryExpr || expression instanceof ASTLeaf) {
            return analyseBinaryExpression(expression, table, isDotExpr);
        } else if (expression instanceof ASTDotExpr) {
            return analyseDotExpression(expression, table);
        } else if (expression instanceof ASTNewExpr) {
            return analyseNewExpression(expression, table);
        } else if (expression instanceof ASTNot) {
            return analyseNotExpression(expression, table);
        } else if (expression instanceof ASTArrayAccess) {
            return analyseArrayAccess(expression, table);
        } else
            return null;
    }


    private String analyseNewExpression(Node expression, SymbolTable table) {
        String returnType = null;
        if (expression.jjtGetChild(1) instanceof ASTArray) {
            String arraySize = analyseExpression(expression.jjtGetChild(1).jjtGetChild(1), table, false);
            if (arraySize != null) {
                if (!arraySize.equals("int")) {
                    printError("Array size must be int.", expression);
                }
            }
            returnType = "int[]";
        } else if (expression.jjtGetChild(1) instanceof ASTId) {
            returnType = ((SimpleNode) expression.jjtGetChild(1)).image;
        }
        final String name = ((SimpleNode) expression.jjtGetChild(0)).image;
        SymbolTable symTable = getTable(name, table);
        if (symTable != null) {
            symTable.setInitialized(name);
        } else {
            table.setInitialized(name);
        }
        return returnType;
    }

    private String analyseNotExpression(Node expression, SymbolTable table) {
        String exprType = analyseExpression(expression.jjtGetChild(0), table, false);
        if (exprType != null) {
            if (!exprType.equals("boolean")) {
                printError("Not operator must be used with boolean expression.", expression);
            }
        }
        return "boolean";
    }

    private String analyseArrayAccess(Node expression, SymbolTable table) {
        String type = null;
        if (expression.jjtGetChild(0) instanceof ASTLeaf) {
            type = getTypeOrFail(((SimpleNode) expression.jjtGetChild(0)).image, table, expression);
        }
        if (type != null) {
            if (!type.equals("int[]")) {
                printError("Identifier must be array.", expression);
            }
        }
        String index = analyseExpression(expression.jjtGetChild(1), table, false);
        if (index != null) {
            if (!index.equals("int")) {
                printError("Array index must be int.", expression);
            }
        }
        return "int";
    }

    private String analyseDotExpression(Node expression, SymbolTable table) {
        Node lhs = expression.jjtGetChild(0);
        Node rhs = expression.jjtGetChild(1);
        String expecting = null;
        String ret = analyseExpression(lhs, table, true);
        if (ret != null) {
            if (ret.equals("int[]")) {
                expecting = "length";
            } else if (ret.equals(className) || ret.equals("this")) {
                if (ret.equals("this") && this.staticContext) {
                    printError("Cannot use keyword this in a static context.", expression);
                    expecting = "anyMethod";
                } else {
                    if (this.hasSuper)
                        expecting = "anyMethod";
                    else
                        expecting = "classMethod";
                }
            } else if (ret.equals("boolean") || ret.equals("int")) {
                printError("Invalid expression.", expression);
            } else {
                expecting = "anyMethod";
            }
        } else {
            expecting = "anyMethod";
        }

        if (rhs instanceof ASTAfterDotExpression) {
            if (((ASTAfterDotExpression) rhs).getType().equals("length")) {
                if (expecting != null) {
                    if (!expecting.equals("length")) {
                        printError("Illegal call.", rhs);
                    }
                }
                return "int";
            } else if (((ASTAfterDotExpression) rhs).getType().equals("method")) {
                if (expecting.equals("anyMethod")) {
                    getMethodSingatureFromCall(rhs, table);
                    return null;
                } else if (expecting.equals("classMethod")) {
                    String signature = getMethodSingatureFromCall(rhs, table).toString();
                    if (signature != null) {
                        if (!symbolTables.containsKey(signature)) {
                            printError("Method " + signature + " is not defined.", rhs);
                            return null;
                        } else {
                            return symbolTables.get(signature).getReturnType();
                        }
                    }
                }
            }
        }
        return null;
    }


    private String analyseBinaryExpression(Node expression, SymbolTable table, boolean isDotExpression) {
        expression = (SimpleNode) expression;
        if (expression.jjtGetNumChildren() == 0) { // if leaf, return type
            if (expression instanceof ASTLeaf) { // all expression leafs must be Expr1
                ASTLeaf leaf = (ASTLeaf) expression;
                switch (leaf.getType()) {
                    case JmmConstants.IDENTIFIER:
                        SymbolTable symTable = getTable(leaf.getName(), table);
                        if (symTable != null) {
                            if (!symTable.getInitialized(leaf.getName())) {
                                printError("Variable " + leaf.getName() + " not initialized", expression);
                            }
                        }
                        if (!isDotExpression) {
                            return getTypeOrFail(leaf.getName(), table, expression);
                        } else {
                            return getType(leaf.getName(), table, expression);
                        }
                    case JmmConstants.INTEGERLITERAL:
                        return "int";
                    case JmmConstants.TRUE:
                    case JmmConstants.FALSE:
                        return "boolean";
                    case JmmConstants.THIS:
                        return "this";
                }
            } else
                return null;
        } else { // intermediate node
            if (expression instanceof ASTBinaryExpr) {
                ASTBinaryExpr node = (ASTBinaryExpr) expression;
                String termTypes = "";
                String returnType = "";
                switch (node.image) {
                    case "<":
                        termTypes = "int";
                        returnType = "boolean";
                        break;
                    case "&&":
                        termTypes = "boolean";
                        returnType = "boolean";
                        break;
                    case "+":
                    case "-":
                    case "*":
                    case "/":
                        termTypes = "int";
                        returnType = "int";
                        break;
                }
                String left = analyseBinaryExpression(node.jjtGetChild(0), table, isDotExpression);
                String right = analyseBinaryExpression(node.jjtGetChild(1), table, isDotExpression);
                if (left != null && right != null) {
                    if (!left.equals(right)) {
                        printError("Term types dont match", expression);
                    } else if (left != termTypes) {
                        printError("Expecting another type", expression);
                    }
                }
                return returnType;
            }
        }
        return null;
    }

    private SymbolTable getTable(String name, SymbolTable table) {
        if (table != null) {
            if (table.getVariables().containsKey(name) || table.getParameters().containsKey(name)) {
                return table;
            }
        }
        if (!this.staticContext) {
            if (globalSymbolTable.getVariables().containsKey(name) || globalSymbolTable.getParameters().containsKey(name)) {
                return globalSymbolTable;
            }
        }
        return null;
    }

    private String getTypeOrFail(String name, SymbolTable table, Node node) {
        String type = getType(name, table, node);
        if (type == null) {
            printError("Variable " + name + " was not defined.", node);
        }
        return type;
    }

    private String getType(String name, SymbolTable table, Node node) {
        if (table != null) {
            if (table.getVariables().containsKey(name)) {
                return table.getVariables().get(name).getType();
            } else if (table.getParameters().containsKey(name)) {
                return table.getParameters().get(name).getType();
            }
        }
        if (!this.staticContext) {
            if (globalSymbolTable.getVariables().containsKey(name)) {
                return globalSymbolTable.getVariables().get(name).getType();
            } else if (globalSymbolTable.getParameters().containsKey(name)) {
                return globalSymbolTable.getParameters().get(name).getType();
            }
        }
        return null;
    }

    /**
     * Gets method singature from call.
     *
     * @param expression the expression
     * @param table      the table
     * @return the method singature from call
     */
    public MethodSignature getMethodSingatureFromCall(Node expression, SymbolTable table) {
        boolean error = false;
        ASTAfterDotExpression call = (ASTAfterDotExpression) expression;
        MethodSignature m = new MethodSignature(call.image);
        for (int i = 0; i < call.jjtGetNumChildren(); i++) {
            String p = analyseExpression(call.jjtGetChild(i), table, false);
            if (p == null) {
                error = true;
            } else {
                m.addParameter(p);
            }
        }
        if (!error)
            return m;
        else
            return null;
    }

    /**
     * Print all symbol tables.
     */
    public void printAllSymbolTables() {
        printSymbolTable("Global", globalSymbolTable);
        for (Map.Entry<String, SymbolTable> table : symbolTables.entrySet()) {
            printSymbolTable(table.getKey(), table.getValue());
        }
    }

    private void printSymbolTable(String name, SymbolTable table) {
        System.out.println(name);
        System.out.println(" -> return type: " + table.getReturnType());
        System.out.println(" -> parameters: " + table.getParameters().size());

        for (Map.Entry<String, Symbol> entry : table.getParameters().entrySet()) {
            System.out.println("    * " + entry.getValue().getType() + " " + entry.getKey());
        }

        System.out.println(" -> local variables: " + table.getVariables().size());
        for (Map.Entry<String, Symbol> entry : table.getVariables().entrySet()) {
            System.out.println("    * " + entry.getValue().getType() + " " + entry.getKey());
        }

        System.out.println();
    }

    private void printRedefinedVar(String name, Node node) {
        printError("Variable " + name + " already declared in scope.", node);
    }

    private void printRedefinedMethod(String name, Node node) {
        printError("Method " + name + " already declared in scope.", node);
    }

    private void printRedefinedParameter(String param, String method, Node node) {
        printError("Parameter " + param + " already declared in method " + method + ".", node);
    }

    private void printWrongReturnType(Node node) {
        printError("Method has wrong return type", node);
    }

    private void printError(String message, Node node) {
        Messages.getInstance().semanticError(((SimpleNode) node).getLineNumber(), message);
        this.error = true;
    }

}