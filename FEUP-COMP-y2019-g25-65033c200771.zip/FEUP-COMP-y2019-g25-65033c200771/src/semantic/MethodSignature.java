package semantic;

import AST.*;

import java.util.ArrayList;

/**
 * The type Method signature.
 */
public class MethodSignature {
    private ArrayList<String> parameters = new ArrayList<>();
    private String name;

    /**
     * Instantiates a new Method signature.
     *
     * @param name the name
     */
    MethodSignature(String name) {
        this.name = name;
    }

    /**
     * From declaration method signature.
     *
     * @param declaration the declaration
     * @return the method signature
     */
    public static MethodSignature fromDeclaration(SimpleNode declaration) {
        if (declaration instanceof ASTMainDeclaration) {
            MethodSignature m = new MethodSignature("main");
            m.addParameter("String[]");
            return m;
        } else if (declaration instanceof ASTMethodDeclaration) {
            final ASTParameters parameters = (ASTParameters) declaration.jjtGetChild(1);
            MethodSignature m = new MethodSignature(declaration.getName());
            for (int i = 0; i < parameters.jjtGetNumChildren(); i++) {
                ASTType type = (ASTType) parameters.jjtGetChild(i).jjtGetChild(0);
                m.addParameter(type.getName());
            }
            return m;
        }
        return null;
    }

    /**
     * Add parameter.
     *
     * @param param the param
     */
    void addParameter(String param) {
        this.parameters.add(param);
    }

    /**
     * Gets parameters.
     *
     * @return the parameters
     */
    public ArrayList<String> getParameters() {
        return parameters;
    }

    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        String params = "";
        for (int i = 0; i < parameters.size(); i++) {
            params += parameters.get(i) + ((i < parameters.size() - 1) ? "," : "");
        }
        return name + "(" + params + ")";
    }
}