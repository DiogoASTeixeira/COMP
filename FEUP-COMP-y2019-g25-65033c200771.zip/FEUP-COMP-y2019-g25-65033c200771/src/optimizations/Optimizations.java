package optimizations;

public class Optimizations{

    private boolean optionR = false;
    private int optionRValue = 0;
    private boolean optionO = false;
    private boolean optionS = false;


    public Optimizations(){}

    public void setOptionR(boolean bool){
        this.optionR = bool;
        this.optionRValue = 0;
    }

    public void setOptionR(boolean bool, int value){
        this.optionR = bool;
        this.optionRValue = value;
    }

    public void setOptionO(boolean bool){
        this.optionO = bool;
    }

    public void setOptionS(boolean bool){
        this.optionS = bool;
    }
  
    public boolean getOptionR(){
        return optionR;
    }

    public int getOptionRValue(){
        return optionRValue;
    }

    public boolean getOptionO(){
        return optionO;
    }

    public boolean getOptionS(){
        return optionS;
    }
}