package symbol;

/**
 * The type Symbol.
 */
public class Symbol {

    private String name, type;
    private boolean initialized;
    private int index;
    private int constant;

    /**
     * Instantiates a new Symbol.
     *
     * @param name        the name
     * @param type        the type
     * @param initialized is initialized
     * @param index       the index
     */
    Symbol(String name, String type, boolean initialized, int index) {
        this.name = name;
        this.type = type;
        this.initialized = initialized;
        this.index = index;
        this.constant = -1;
    }

    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Gets type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets type.
     *
     * @param type the type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Sets initialized.
     */
    void setInitialized() {
        this.initialized = true;
    }

    /**
     * Gets initialized.
     *
     * @return the initialized
     */
    boolean getInitialized() {
        return this.initialized;
    }

    /**
     * Gets index.
     *
     * @return the index
     */
    int getIndex() {
        return index;
    }

    /**
     * Sets constant.
     *
     * @param constant the constant
     */
    void setConstant(int constant) {
        this.constant = constant;
    }

    /**
     * Gets constant.
     *
     * @return the constant
     */
    int getConstant() {
        return constant;
    }
}