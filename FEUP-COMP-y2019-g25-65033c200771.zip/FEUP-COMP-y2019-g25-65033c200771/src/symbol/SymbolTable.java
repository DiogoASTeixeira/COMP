package symbol;

import java.util.LinkedHashMap;

/**
 * The type Symbol table.
 */
public class SymbolTable {

    /**
     * The Loop counter.
     */
    public int loopCounter = 0;
    private LinkedHashMap<String, Symbol> parameters = new LinkedHashMap<>();
    private LinkedHashMap<String, Symbol> variables = new LinkedHashMap<>();
    private String functionName;
    private String returnType;

    /**
     * Instantiates a new Symbol table.
     */
    public SymbolTable() {
    }

    /**
     * Gets parameters.
     *
     * @return the parameters
     */
    public LinkedHashMap<String, Symbol> getParameters() {
        return parameters;
    }

    /**
     * Gets variables.
     *
     * @return the variables
     */
    public LinkedHashMap<String, Symbol> getVariables() {
        return variables;
    }

    /**
     * Gets function name.
     *
     * @return the function name
     */
    public String getFunctionName() {
        return functionName;
    }

    /**
     * Sets function name.
     *
     * @param functionName the function name
     */
    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

    /**
     * Gets return type.
     *
     * @return the return type
     */
    public String getReturnType() {
        return returnType;
    }

    /**
     * Sets return type.
     *
     * @param returnType the return type
     */
    public void setReturnType(String returnType) {
        this.returnType = returnType;
    }

    /**
     * Add parameter.
     *
     * @param name the name
     * @param type the type
     */
    public void addParameter(String name, String type) {
        if (functionName != null && functionName.equals("main")) {
            this.addParametersMain(name, type);
        } else {
            int index = this.parameters.size() + 1;
            this.parameters.put(name, new Symbol(name, type, true, index));
        }
    }

    private void addParametersMain(String name, String type) {
        int index = this.parameters.size();
        this.parameters.put(name, new Symbol(name, type, true, index));
    }

    /**
     * Add variable.
     *
     * @param name the name
     * @param type the type
     */
    public void addVariable(String name, String type) {
        if (functionName != null && functionName.equals("main")) {
            this.addVariablesMain(name, type);
        } else {
            int index = this.parameters.size() + this.variables.size() + 1;
            this.variables.put(name, new Symbol(name, type, false, index));
        }
    }

    private void addVariablesMain(String name, String type) {
        int index = this.parameters.size() + this.variables.size();
        this.variables.put(name, new Symbol(name, type, false, index));
    }

    /**
     * Sets initialized.
     *
     * @param variable the variable
     */
    public void setInitialized(String variable) {
        if (this.variables.containsKey(variable))
            this.variables.get(variable).setInitialized();
    }

    /**
     * Gets initialized.
     *
     * @param variable the variable
     * @return if initialized
     */
    public boolean getInitialized(String variable) {
        if (this.variables.containsKey(variable)) return this.variables.get(variable).getInitialized();
        else if (this.parameters.containsKey(variable)) return true;
        return false;
    }

    /**
     * Gets index.
     *
     * @param variable the variable
     * @return the index
     */
    public int getIndex(String variable) {
        if (this.variables.containsKey(variable)) return this.variables.get(variable).getIndex();
        else if (this.parameters.containsKey(variable)) return this.parameters.get(variable).getIndex();
        return -1;
    }

    /**
     * Sets constant.
     *
     * @param variable the variable
     * @param constant the constant
     */
    public void setConstant(String variable, int constant) {
        if (this.variables.containsKey(variable))
            this.variables.get(variable).setConstant(constant);
    }

    /**
     * Gets constant.
     *
     * @param variable the variable
     * @return the constant
     */
    public int getConstant(String variable) {
        if (this.variables.containsKey(variable))
            return this.variables.get(variable).getConstant();
        return -1;
    }
}