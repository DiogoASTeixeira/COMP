public class Constants {
	public static final int ADD = 1;
	public static final int SUB = 2;
	public static final int MUL = 3;
	public static final int DIV = 4;

	public static final char[] ops = {'+','-','*','/'};
}