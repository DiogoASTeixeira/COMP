package codeGeneration;

import AST.*;
import semantic.*;
import symbol.Symbol;
import symbol.SymbolTable;
import optimizations.*;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;


/**
 * CodeGeneration class responsible for generating jasmin code from the previous built AST
 */
public class CodeGeneration {

    private SemanticAnalysis semantic;
    private PrintWriter file;
    private SimpleNode root;
    private Stack stack;
    private Optimizations optimizations;

    /**
     * Instantiates a new Code generation.
     *
     * @param root           the root, root Node of the AST
     * @param semantic       the semantic, semantic object
     * @param optimizations the optimizations values
     */
    public CodeGeneration(SimpleNode root, SemanticAnalysis semantic, Optimizations optimizations) {
        this.root = (SimpleNode) root.jjtGetChild(0);
        this.semantic = semantic;
        this.optimizations = optimizations;
    }

    /**
     * Creates the file to which the jasmin code will be written to
     */
    public void getFile() {

        try {
            File jasminFolder = new File("jasmin");
            if (!jasminFolder.exists())
                jasminFolder.mkdirs();

            File classFile = new File("jasmin/" + semantic.getClassName() + ".j");
            if (!classFile.exists())
                classFile.createNewFile();
            file = new PrintWriter(classFile);
        } catch (IOException e) {
            System.out.println(e.getMessage());
            System.exit(1);
        }

    }

    /**
     * Generate code Jmm to JVM (jasmin)
     *
     * @return the boolean
     */
    public boolean jmmToJvm() {
        this.getFile();
        this.header();
        file.println();
        this.globals();
        file.println();
        this.constructor();
        file.println();
        this.functions();
        file.close();
        return true;

    }

    private void header() {
        file.println(".class public " + root.getName());
        if (((ASTClassDeclaration) root).hasSuper()) {
            file.print(".super " + ((ASTClassDeclaration) root).getSuper());
        } else {
            file.println(".super java/lang/Object");
        }

    }

    private void globals() {
        for (int i = 0; i < root.jjtGetNumChildren(); i++) {
            if (root.jjtGetChild(i) instanceof ASTVarDeclaration) {
                this.global((ASTVarDeclaration) root.jjtGetChild(i));
            }
        }
    }

    private void global(ASTVarDeclaration node) {
        String name, type;
        name = ((ASTIdentifier) node.jjtGetChild(1)).image;
        type = getType((node.jjtGetChild(0)).toString(), false);

        file.println(".field public " +  "'" + name + "'" + " " + type);

    }

    private void constructor() {
        file.println(".method public <init>()V");
        file.println("\taload_0");
        if (((ASTClassDeclaration) root).hasSuper()) {
            file.println("\tinvokespecial " + ((ASTClassDeclaration) root).getSuper() + "/<init>()V");
        } else {
            file.println("\tinvokespecial java/lang/Object/<init>()V");
        }
        file.println("\treturn");
        file.println(".end method");
    }

    private String getType(String type, boolean forInvoke) {
        switch (type) {
        case "int":
            return "I";
        case "boolean":
            return "Z";
        case "int[]":
            return "[I";
        case "void":
            return "V";
        default:
            return (forInvoke ? ("L" + type + ";") : type);

        }
    }

    private void functions() {
        for (int i = 0; i < root.jjtGetNumChildren(); i++) {
            if (root.jjtGetChild(i) instanceof ASTMainDeclaration) {
                this.main((ASTMainDeclaration) root.jjtGetChild(i));
            } else if (root.jjtGetChild(i) instanceof ASTMethodDeclaration) {
                this.function((ASTMethodDeclaration) root.jjtGetChild(i));
            }
        }
    }

    private void main(ASTMainDeclaration node) {
        this.stack = new Stack();
        this.mainHeader(node);
        String body = this.functionBody(node);
        file.println("\t.limit stack " + this.stack.getMax());
        file.print(body);
        file.println("\treturn");
        file.println(".end method");
        file.println();
    }

    private void mainHeader(ASTMainDeclaration node) {
        String sig = MethodSignature.fromDeclaration(node).toString();
        file.println(".method public static main([Ljava/lang/String;)V");
        int locals = this.semantic.getSymbolTables().get(sig).getParameters().size();
        locals += this.semantic.getSymbolTables().get(sig).getVariables().size();
        file.println("\t.limit locals " + locals);
    }

    private String functionDescriptor(String name, SymbolTable function) {
        String args = "", returnType;
        for (Symbol param : function.getParameters().values()) {
            args += this.getType(param.getType(), true);
        }

        returnType = this.getType(function.getReturnType(), true);
        return name + "(" + args + ")" + returnType;
    }

    private void functionHeader(ASTMethodDeclaration node) {
        String signature = MethodSignature.fromDeclaration(node).toString();
        SymbolTable function = semantic.getSymbolTables().get(signature);

        file.println(".method public " + this.functionDescriptor(function.getFunctionName(), function));
        int locals = 1 + this.semantic.getSymbolTables().get(signature).getParameters().size();
        locals += this.semantic.getSymbolTables().get(signature).getVariables().size();
        file.println("\t.limit locals " + locals);
    }

    private void function(ASTMethodDeclaration node) {
        this.stack = new Stack();
        this.functionHeader(node);
        String body = this.functionBody(node);
        file.println("\t.limit stack " + this.stack.getMax());
        file.print(body);
        file.println(".end method");
        file.println();
    }

    private String functionBody(SimpleNode function) {
        StringBuilder body = new StringBuilder();
        String signature = MethodSignature.fromDeclaration(function).toString();
        SymbolTable sTable = semantic.getSymbolTables().get(signature);
        for (int i = 0; i < function.jjtGetNumChildren(); i++) {

            if (function.jjtGetChild(i) instanceof ASTReturn) {

                expression(function.jjtGetChild(i).jjtGetChild(0), sTable, body, false, sTable.getReturnType());
                this.stack.popStack(1);
                if (sTable.getReturnType().equals("int") || sTable.getReturnType().equals("boolean")) {
                    body.append("\tireturn" + "\n");
                } else {
                    body.append("\tareturn" + "\n");
                }

            } else if (function.jjtGetChild(i) instanceof ASTIdentifier) {
                continue;
            } else {
                if (i == (function.jjtGetNumChildren() - 1))
                    statement(function.jjtGetChild(i), null, sTable, body);
                else
                    statement(function.jjtGetChild(i), function.jjtGetChild(i + 1), sTable, body);
            }

        }

        return body.toString();
    }

    private void dotExpression(ASTDotExpr dot, SymbolTable sTable, StringBuilder body, boolean pop,
            String expectedReturn) {
        if (dot.jjtGetChild(1) instanceof ASTAfterDotExpression) {
            if (((ASTAfterDotExpression) dot.jjtGetChild(1)).image.equals("length")) {
                arrayLength(dot, sTable, body);
            } else {
                functionCall(dot, sTable, body, pop, expectedReturn);
            }
        }
    }

    private void arrayLength(ASTDotExpr dot, SymbolTable sTable, StringBuilder body) {
        expression(dot.jjtGetChild(0), sTable, body, false, "int[]");
        this.stack.popStack(1);
        this.stack.pushToStack(1);
        body.append("\tarraylength\n");
    }

    private void functionCall(ASTDotExpr dot, SymbolTable sTable, StringBuilder body, boolean pop,
            String expectedReturn) {
        ASTAfterDotExpression function = null;
        SymbolTable s = null;
        boolean staticFunction = false;
        Node object = null;
        String className = "";

        for (int i = 0; i < dot.jjtGetNumChildren(); i++) {
            if (dot.jjtGetChild(i) instanceof ASTAfterDotExpression) {
                function = (ASTAfterDotExpression) dot.jjtGetChild(i);
                String signature = semantic.getMethodSingatureFromCall(dot.jjtGetChild(i), sTable).toString();
                s = this.semantic.getSymbolTables().get(signature);
                object = dot.jjtGetChild(i - 1);

                if (object instanceof ASTIdentifier
                        || (object instanceof ASTLeaf && ((ASTLeaf) object).getType() == JmmConstants.IDENTIFIER)) {
                    Symbol var;
                    var = sTable.getParameters().get(object.getName());
                    if (var == null) {
                        var = sTable.getVariables().get(object.getName());
                        if (var == null) {
                            var = semantic.getGlobalSymbolTable().getVariables().get(object.getName());
                        }
                    }

                    if (var != null) {
                        className = var.getType();
                    } else {
                        className = object.getName();
                        staticFunction = true;
                    }

                } else if (object instanceof ASTLeaf && ((ASTLeaf) object).getType() == JmmConstants.THIS) {
                    if (s != null) {
                        className = root.getName();

                    } else {
                        className = ((ASTClassDeclaration) root).getSuper();

                    }
                } else if (object instanceof ASTNewExpr) {
                    className = ((ASTId) object.jjtGetChild(1)).image;
                } else if (object instanceof ASTAfterDotExpression) {
                    String sig = semantic.getMethodSingatureFromCall(object.jjtGetChild(1), sTable).toString();
                    SymbolTable table = this.semantic.getSymbolTables().get(sig);
                    if (table == null) {
                        className = root.getName();
                    } else {
                        className = table.getReturnType();
                    }
                }

                expression(object, sTable, body, false, className);
            }
        }

        if (function != null) {

            for (int i = 0; i < function.jjtGetNumChildren(); i++) {
                String argReturn = "";
                if (s != null) {
                    MethodSignature sig = semantic.getMethodSingatureFromCall(function, sTable);
                    argReturn = sig.getParameters().get(i);
                }
                expression(function.jjtGetChild(i), sTable, body, false, argReturn);
            }

            this.stack.popStack(function.jjtGetNumChildren());

            String returnType;

            if (s != null) {
                returnType = s.getReturnType();
            } else {
                returnType = expectedReturn;
            }

            String prefix = staticFunction ? "\tinvokestatic " : "\tinvokevirtual ";
            body.append(prefix + className + "/" + parseSignature(function, sTable) + this.getType(returnType, true)
                    + "\n");

            if (!staticFunction) {
                this.stack.popStack(1);
            }

            if (!returnType.equals("void")) {
                this.stack.pushToStack(1);
            }

            if (pop && !returnType.equals("void")) {
                body.append("\tpop\n");
                this.stack.popStack(1);
            }
        }
    }

    private String parseSignature(ASTAfterDotExpression function, SymbolTable sTable) {
        MethodSignature sig = semantic.getMethodSingatureFromCall(function, sTable);
        String sigStr = sig.getName() + "(";
        for (String p : sig.getParameters()) {
            sigStr += getType(p, true);
        }
        return sigStr + ")";
    }

    private void storeArray(Node array, SymbolTable sTable, StringBuilder body) {

        expression(array.jjtGetChild(0).jjtGetChild(0), sTable, body, false, "int[]");
        expression(array.jjtGetChild(0).jjtGetChild(1), sTable, body, false, "int");
        expression(array.jjtGetChild(1), sTable, body, false, "int");
        this.stack.popStack(3);
        body.append("\tiastore\n");

    }

    private void statement(Node node, Node followingNode, SymbolTable sTable, StringBuilder body) {

        if (node instanceof ASTIdentifierStat) {
            ASTIdentifierStat assign = (ASTIdentifierStat) node;
            ASTIdentifier identifier = null;

            if (assign.jjtGetChild(0).jjtGetChild(0) instanceof ASTIdentifier) {      
                if (!iinc(assign, sTable, body)) {
                    identifier = (ASTIdentifier) assign.jjtGetChild(0).jjtGetChild(0);

                    if (this.semantic.getGlobalSymbolTable().getVariables().get(identifier.image) != null
                            && sTable.getIndex(identifier.image) == -1) {
                        body.append("\taload_0" + "\n");
                        this.stack.pushToStack(1);
                    }

                    Symbol id;
                    id = sTable.getParameters().get(identifier.image);
                    if (id == null) {
                        id = sTable.getVariables().get(identifier.image);
                        if (id == null) {
                            this.semantic.getGlobalSymbolTable().getVariables().get(identifier.image);
                        }
                    }
                    expression(assign.jjtGetChild(0).jjtGetChild(1), sTable, body, false,
                            (id == null ? identifier.image : id.getType()));
                    body.append(this.loadVariable(identifier.image, sTable) + "\n");
                }
            } else if (assign.jjtGetChild(0).jjtGetChild(0) instanceof ASTArrayAccess) {
                storeArray(assign.jjtGetChild(0), sTable, body);
            }
        } else if (node instanceof ASTIf) {
            this.ifStatement((ASTIf) node, (ASTElse) followingNode, sTable, body);
        } else if (node instanceof ASTWhile) {
            this.whileStatement((ASTWhile) node, sTable, body);
        } else if (node instanceof ASTExprStmt) {
            statement(node.jjtGetChild(0), null, sTable, body);
        } else if (node instanceof ASTDotExpr && node.jjtGetChild(1) instanceof ASTAfterDotExpression
                && !((ASTAfterDotExpression) node.jjtGetChild(1)).image.equals("length")) {
            expression(node, sTable, body, true, "void");
        }
    }

    private boolean iinc(ASTIdentifierStat statement, SymbolTable sTable, StringBuilder body) {
        ASTIdentifier identifier = (ASTIdentifier) statement.jjtGetChild(0).jjtGetChild(0);
        if (statement.jjtGetChild(0).jjtGetChild(1) instanceof ASTBinaryExpr) {
            ASTBinaryExpr binaryExpression = (ASTBinaryExpr) statement.jjtGetChild(0).jjtGetChild(1);
            if (!(binaryExpression.image.equals("-") || binaryExpression.image.equals("+")))
                return false;
            else if (binaryExpression.jjtGetChild(0) instanceof ASTLeaf
                    && binaryExpression.jjtGetChild(1) instanceof ASTLeaf) {
                ASTLeaf op1 = (ASTLeaf) binaryExpression.jjtGetChild(0);
                ASTLeaf op2 = (ASTLeaf) binaryExpression.jjtGetChild(1);
                String ident = null;
                int constant = 0;
                switch (op1.getType()) {
                case JmmConstants.IDENTIFIER:
                    ident = op1.getName();
                    break;
                case JmmConstants.INTEGERLITERAL:
                    constant = Integer.parseInt(op1.getName());
                default:
                    return false;
                }
                if (ident == null) {
                    if (op2.getType() == JmmConstants.IDENTIFIER)
                        ident = op2.getName();
                    else
                        return false;
                } else if (op2.getType() == JmmConstants.INTEGERLITERAL)
                    constant = Integer.parseInt(op2.getName());
                else
                    return false;
                if (identifier.image.equals(ident)) {
                    int index = sTable.getIndex(identifier.image);
                    if (index != -1) {
                        if (binaryExpression.image.equals("+"))
                            body.append("\tiinc " + index + " " + constant + "\n");
                        else
                            body.append("\tiinc " + index + " -" + constant + "\n");
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void expression(Node expression, SymbolTable sTable, StringBuilder body, boolean pop,
            String expectedReturn) {
        if (expression instanceof ASTBinaryExpr) {
            arithmeticExpression(expression, sTable, body);
        } else if (expression instanceof ASTNewExpr) {
            callConstructor((ASTNewExpr) expression, sTable, body);
        } else if (expression instanceof ASTLeaf || expression instanceof ASTIdentifier) {
            body.append(pushVariable(expression, sTable));
        } else if (expression instanceof ASTNot) {
            arithmeticExpression(expression, sTable, body);
        } else if (expression instanceof ASTDotExpr) {
            dotExpression((ASTDotExpr) expression, sTable, body, pop, expectedReturn);
        } else if (expression instanceof ASTArrayAccess) {
            expression(expression.jjtGetChild(0), sTable, body, false, "int[]");
            expression(expression.jjtGetChild(1), sTable, body, false, "int");
            this.stack.popStack(2);
            this.stack.pushToStack(1);
            body.append("\tiaload\n");
        }
    }

    private void callConstructor(ASTNewExpr constructor, SymbolTable sTable, StringBuilder body) {

        if (constructor.jjtGetChild(1) instanceof ASTId) {
            String className = ((ASTId) constructor.jjtGetChild(1)).image;
            body.append("\tnew " + className + "\n");
            this.stack.pushToStack(1);
            body.append("\tdup" + "\n");
            this.stack.pushToStack(1);
            body.append("\tinvokespecial " + className + "/<init>()V" + "\n");
            this.stack.popStack(1);

        } else if (constructor.jjtGetChild(1) instanceof ASTArray) {
            expression(constructor.jjtGetChild(1).jjtGetChild(1), sTable, body, false, "int[]");
            body.append("\tnewarray int\n");
            this.stack.popStack(1);
            this.stack.pushToStack(1);
        }
    }

    private String pushVariable(Node expression, SymbolTable sTable) {
        if (expression instanceof ASTLeaf) {
            ASTLeaf leaf = (ASTLeaf) expression;
            switch (leaf.getType()) {
            case JmmConstants.IDENTIFIER:
                int index = sTable.getIndex(leaf.getName());
                int constant = sTable.getConstant(leaf.getName());
                if (optimizations.getOptionO() && constant != -1) {
                    this.stack.pushToStack(1);
                    if (constant > 32767) {
                        return ("\tldc " + constant + "\n");
                    } else if (constant > 127) {
                        return ("\tsipush " + constant + "\n");
                    } else if (constant > 5) {
                        return ("\tbipush " + constant + "\n");
                    } else {
                        return ("\ticonst_" + constant + "\n");
                    }

                } else if (index != -1) {
                    Symbol arg = sTable.getParameters().get(leaf.getName());
                    if (arg == null) {
                        arg = sTable.getVariables().get(leaf.getName());
                    }
                    if (arg.getType().equals("int") || arg.getType().equals("boolean")) {
                        this.stack.pushToStack(1);
                        return ("\tiload" + (index > 3 ? " " : "_") + index + "\n");
                    } else {
                        this.stack.pushToStack(1);
                        return ("\taload" + (index > 3 ? " " : "_") + index + "\n");
                    }
                } else {
                    Symbol attr = this.semantic.getGlobalSymbolTable().getVariables().get(leaf.getName());
                    if (attr != null) {
                        this.stack.pushToStack(2);
                        this.stack.popStack(1);
                        return "\taload_0\n\tgetfield " + root.getName() + "/" + attr.getName() + " "
                                + this.getType(attr.getType(), true) + "\n";
                    }
                }

                break;
            case JmmConstants.INTEGERLITERAL:
                this.stack.pushToStack(1);
                if (Integer.parseInt(leaf.getName()) > 32767) {
                    return ("\tldc " + leaf.getName() + "\n");
                } else if (Integer.parseInt(leaf.getName()) > 127) {
                    return ("\tsipush " + leaf.getName() + "\n");
                } else if (Integer.parseInt(leaf.getName()) > 5) {
                    return ("\tbipush " + leaf.getName() + "\n");
                } else {
                    return ("\ticonst_" + leaf.getName() + "\n");
                }
            case JmmConstants.THIS:
                this.stack.pushToStack(1);
                return ("\taload_0\n");
            case JmmConstants.TRUE:
                this.stack.pushToStack(1);
                return "\ticonst_1\n";
            case JmmConstants.FALSE:
                this.stack.pushToStack(1);
                return "\ticonst_0\n";
            default:
            }
        } else if (expression instanceof ASTIdentifier) {
            ASTIdentifier identifier = (ASTIdentifier) expression;
            int index = sTable.getIndex(identifier.image);
            if (index != -1) {
                this.stack.pushToStack(1);
                return ("\taload" + (index > 4 ? " " : "_") + index + "\n");
            } else {
                Symbol attr = this.semantic.getGlobalSymbolTable().getVariables().get(identifier.image);
                if (attr != null) {
                    this.stack.pushToStack(2);
                    this.stack.popStack(1);
                    return "\taload_0\n\tgetfield " + root.getName() + "/" + attr.getName() + " "
                            + this.getType(attr.getType(), true) + "\n";
                }
            }
        }

        return "";
    }

    private String loadVariable(String name, SymbolTable sTable) {
        int index = sTable.getIndex(name);
        if (index != -1) {
            Symbol arg = sTable.getParameters().get(name);
            if (arg == null) {
                arg = sTable.getVariables().get(name);
            }
            if (arg.getType().equals("int") || arg.getType().equals("boolean")) {
                this.stack.popStack(1);
                return ("\tistore" + (index > 3 ? " " : "_") + index);
            } else {
                this.stack.popStack(1);
                return ("\tastore" + (index > 3 ? " " : "_") + index);
            }
        } else {
            Symbol attr = this.semantic.getGlobalSymbolTable().getVariables().get(name);
            if (attr != null) {
                this.stack.pushToStack(1);
                this.stack.popStack(2);
                return "\tputfield " + root.getName() + "/" + attr.getName() + " " + this.getType(attr.getType(), true);
            }
        }
        return "";
    }

    private void arithmeticExpression(Node expression, SymbolTable sTable, StringBuilder body) {

        if (expression.jjtGetNumChildren() == 1) {
            expression(expression.jjtGetChild(0), sTable, body, false, "boolean");
            body.append("\ticonst_1\n");
            body.append("\tixor\n");
        } else {
            if (expression instanceof ASTBinaryExpr) {

                if(optimizations.getOptionS() && expression.jjtGetChild(0) instanceof ASTLeaf && expression.jjtGetChild(1) instanceof ASTLeaf){
                    strengthReduction((ASTBinaryExpr) expression);
                }

                if (((ASTBinaryExpr) expression).image.equals("&&")) {

                    sTable.loopCounter++;
                    int loopNumber = sTable.loopCounter;
                    expression(expression.jjtGetChild(0), sTable, body, false, "boolean");
                    this.stack.popStack(1);
                    body.append("\tifeq loop" + loopNumber + "_next\n");
                    expression(expression.jjtGetChild(1), sTable, body, false, "boolean");
                    body.append("\tgoto loop" + loopNumber + "_end\n");
                    body.append("\tloop" + loopNumber + "_next:\n");
                    body.append("\ticonst_0\n");
                    body.append("\tloop" + loopNumber + "_end:\n");

                } else {
                    expression(expression.jjtGetChild(0), sTable, body, false, "int");
                    expression(expression.jjtGetChild(1), sTable, body, false, "int");

                    switch (((ASTBinaryExpr) expression).image) {
                    case "*":
                        body.append("\timul" + "\n");
                        break;
                    case "/":
                        body.append("\tidiv" + "\n");
                        break;
                    case "-":
                        body.append("\tisub" + "\n");
                        break;
                    case "+":
                        body.append("\tiadd" + "\n");
                        break;
                    case "<":
                        sTable.loopCounter++;
                        int loopNumber = sTable.loopCounter;
                        body.append("\tif_icmplt loop" + loopNumber + "_next\n");
                        body.append("\ticonst_0\n");
                        body.append("\tgoto loop" + loopNumber + "_end\n");
                        body.append("\tloop" + loopNumber + "_next:\n");
                        body.append("\ticonst_1\n");
                        body.append("\tloop" + loopNumber + "_end:\n");
                        break;
                    }
                }
            } else if (expression instanceof ASTArrayAccess) {
                expression(expression.jjtGetChild(0), sTable, body, false, "int[]");
                expression(expression.jjtGetChild(1), sTable, body, false, "int");
            }
        }
    }

    private void strengthReduction(ASTBinaryExpr expression) {
        ASTLeaf constant; 
        ASTLeaf variable;
        if (isConstant((ASTLeaf) expression.jjtGetChild(0))){
            constant = (ASTLeaf) expression.jjtGetChild(0);
            variable = (ASTLeaf) expression.jjtGetChild(1);
        }
        else if (isConstant((ASTLeaf) expression.jjtGetChild(1))){
            constant = (ASTLeaf) expression.jjtGetChild(1);
            variable = (ASTLeaf) expression.jjtGetChild(0);
        }
        else return;
        if (expression.image.equals("*")){
            expression.image = "+";
            constant.setType(variable.getType());
            constant.setName(variable.getName());
        }
        
    }

    private boolean isConstant(ASTLeaf leaf){
        
        return (leaf.getType() == JmmConstants.INTEGERLITERAL &&
            leaf.getName().equals("2"));
    }
    private void ifStatement(ASTIf ifStatement, ASTElse elseStatement, SymbolTable sTable, StringBuilder body) {

        sTable.loopCounter++;
        int loopNumber = sTable.loopCounter;

        for (int i = 0; i < ifStatement.jjtGetNumChildren(); i++) {
            if (ifStatement.jjtGetChild(i) instanceof ASTIfBody) {
                for (int j = 0; j < ifStatement.jjtGetChild(i).jjtGetNumChildren(); j++) {
                    if (j == (ifStatement.jjtGetChild(i).jjtGetNumChildren() - 1))
                        statement(ifStatement.jjtGetChild(i).jjtGetChild(j), null, sTable, body);
                    else
                        statement(ifStatement.jjtGetChild(i).jjtGetChild(j),
                                ifStatement.jjtGetChild(i).jjtGetChild(j + 1), sTable, body);
                }
            } else {
                expression(ifStatement.jjtGetChild(i), sTable, body, false, "boolean");
                body.append("\tifeq loop" + loopNumber + "_else\n");
                this.stack.popStack(1);
            }
        }

        body.append("\tgoto loop" + loopNumber + "_next\n");
        elseStatement(elseStatement, loopNumber, sTable, body);
        body.append("\tloop" + loopNumber + "_next:\n");
    }

    private void elseStatement(ASTElse elseStatement, int loopNumber, SymbolTable sTable, StringBuilder body) {

        body.append("\tloop" + loopNumber + "_else:\n");

        for (int i = 0; i < elseStatement.jjtGetChild(0).jjtGetNumChildren(); i++) {
            if (i == (elseStatement.jjtGetChild(0).jjtGetNumChildren() - 1))
                statement(elseStatement.jjtGetChild(0).jjtGetChild(i), null, sTable, body);
            else
                statement(elseStatement.jjtGetChild(0).jjtGetChild(i), elseStatement.jjtGetChild(0).jjtGetChild(i + 1),
                        sTable, body);
        }

    }

    private void whileStatement(ASTWhile node, SymbolTable sTable, StringBuilder body) {
        sTable.loopCounter++;
        int loopNumber = sTable.loopCounter;
        int i;
        boolean simpleCondition = analyzeCondition(node.jjtGetChild(0));

        if (optimizations.getOptionO() && simpleCondition){
            expression(node.jjtGetChild(0), sTable, body, false, "boolean");
            body.append("\tifeq loop" + loopNumber + "_end\n");
            this.stack.popStack(1);
            body.append("\tloop" + loopNumber + ":\n");

        } else {
            body.append("\tloop" + loopNumber + ":\n");
            expression(node.jjtGetChild(0), sTable, body, false, "boolean");
            body.append("\tifeq loop" + loopNumber + "_end\n");
            this.stack.popStack(1);
        }

        if (node.jjtGetChild(1) instanceof ASTWhileBody) {
            for (int j = 0; j < node.jjtGetChild(1).jjtGetNumChildren(); j++) {
                if (j == (node.jjtGetChild(1).jjtGetNumChildren() - 1))
                    statement(node.jjtGetChild(1).jjtGetChild(j), null, sTable, body);
                else
                    statement(node.jjtGetChild(1).jjtGetChild(j), node.jjtGetChild(1).jjtGetChild(j + 1), sTable,
                            body);
            }
        }

        if (optimizations.getOptionO() && simpleCondition) {
            expression(node.jjtGetChild(0), sTable, body, false, "boolean");
            body.append("\tifne loop" + loopNumber + "\n");
            this.stack.popStack(1);
        } else {
            body.append("\tgoto loop" + loopNumber + "\n");
        }

        body.append("\tloop" + loopNumber + "_end:\n");
    }

    private boolean analyzeCondition(Node node) {

        if (node instanceof ASTLeaf) {
            return true;
        } else if (node instanceof ASTBinaryExpr) {
            ASTBinaryExpr expression = (ASTBinaryExpr) node;
            if (expression.jjtGetChild(0) instanceof ASTLeaf && expression.jjtGetChild(1) instanceof ASTLeaf) {
                return true;
            }
        }
        return false;

    }
}
