package codeGeneration;

/**
 * The type Stack.
 */
class Stack {
    private int max;
    private int current;

    /**
     * Push to stack and calculate new Max
     *
     * @param i number to push to stack
     */
    void pushToStack(int i) {
        current += i;
        if (current > max) {
            max = current;
        }
    }

    /**
     * Pop stack.
     *
     * @param i number to pop from stack
     */
    void popStack(int i) {
        current -= i;
    }

    /**
     * Gets max.
     *
     * @return  max
     */
    int getMax() {
        return max;
    }
}
