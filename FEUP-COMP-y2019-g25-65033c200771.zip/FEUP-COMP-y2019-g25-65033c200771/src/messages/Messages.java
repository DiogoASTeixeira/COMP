package messages;

public class Messages{
    private static Messages instance = new Messages();
    public static String ANSI_RESET = "";
    public static String ANSI_RED = "";
    public static String ANSI_GREEN = "";
    public static String ANSI_CYAN = "";
    public static String ANSI_YELLOW = "";

    private Messages() {
    }


    public static Messages getInstance() {
        return instance;
    }

    public void setColored() {
        ANSI_RESET = "\u001B[0m";
        ANSI_RED = "\u001B[31m";
        ANSI_GREEN = "\u001B[32m";
        ANSI_CYAN = "\u001B[36m";
        ANSI_YELLOW = "\u001B[33m";
    }

    public void readingInput(){
        System.out.println(ANSI_CYAN + "jmm:" + ANSI_RESET + " Reading input ...");
    }

    public void readingFile(String file){

        String[] parts = file.split("/");
        file = parts[parts.length - 1];

        System.out.println(ANSI_CYAN + "jmm:" + ANSI_RESET + " Reading the file " + file + " ...");
    }

    public  void fileNotFound(String file){
        String[] parts = file.split("/");
        file = parts[parts.length - 1];
        System.out.println(ANSI_RED + "jmm:" + ANSI_RESET + " The file " + file + " was not found.");
    }

    public void error(int number, String message){
        System.out.println(ANSI_RED + "jmm: " + ANSI_YELLOW + "error " + number + ": " + ANSI_RESET + message);
    }

    public void success(){
        System.out.println(ANSI_GREEN + "jmm: " + ANSI_RESET + "Parse completed");
    }

    public void failure(String message){
        System.out.println(ANSI_RED + "jmm: " + ANSI_RESET + message);
        System.out.println(ANSI_RED + "jmm:" + ANSI_RESET  + " Parse failed! There was one or more errors during the parse.");
    }

    public void semanticError(int line, String message){
        System.out.println(ANSI_YELLOW+ "jmm: line " + line + ": " + message); 
    }

}
