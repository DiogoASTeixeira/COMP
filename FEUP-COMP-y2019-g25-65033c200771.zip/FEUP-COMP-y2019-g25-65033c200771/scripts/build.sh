#!/bin/bash
cd ../src/
jjtree javamm.jjt
cd AST
javacc javamm.jj
javac *.java 