#!/bin/bash
if [ "$#" -lt 1 ]; then
    echo "usage sh jasmin.sh <file>; file (without the .j extension) must be located under jasmin/"
else
    cd jasmin-2.4
    java -jar jasmin.jar "../../src/jasmin/$1.j"
    java "$1"
fi