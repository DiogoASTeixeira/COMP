#!/bin/bash
cd ../src/
javac AST/*.java
javac codeGeneration/*.java 
javac semantic/*.java
if [[ "$#" -lt 1 ]]; then
	echo "usage: sh run.sh [-o] [-s] [-c] <testfile.jmm>; testfile must be located under test/"
else
	cd ../src/
	if [[ "$#" -eq 1 ]]; then
		java AST.Jmm "../test/$1"
	elif [[ "$#" -eq 2 ]]; then
	    java AST.Jmm "../test/$2" "$1"
	elif [[ "$#" -eq 3 ]]; then
	    java AST.Jmm "../test/$3" "$1" "$2"
	elif [[ "$#" -eq 4 ]]; then
	    java AST.Jmm "../test/$4" "$1" "$2" "$3"
	else echo "usage: sh run.sh [-o] [-s] [-c] <testfile.jmm>; testfile must be located under test/"
    fi
fi