if [ "$#" -lt 1 ]; then
    echo "usage sh run_jasmin.sh <Class>;"
else
    cd jasmin-2.4
    java "$1"
fi